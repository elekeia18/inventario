const express = require('express');
const fs = require('fs');
const cors = require('cors');

const app = express();
const PORT = 5000;

// Habilitar CORS
app.use(cors());

// Leer datos del archivo JSON
const ingenieros = JSON.parse(fs.readFileSync('ingenieros.json', 'utf8'));

// Endpoint raíz
app.get('/', (req, res) => {
    res.send('REST API FROM MY SERVER UBUNTU');
});

// Endpoint para obtener los ingenieros
app.get('/ingenieros', (req, res) => {
    res.json(ingenieros);
});

// Iniciar el servidor
app.listen(PORT, () => {
    console.log(`Servidor corriendo en http://localhost:${PORT}`);
});
